explosao
- Delay -
active: false
- Duration -
lowMin: 400.0
lowMax: 400.0
- Count -
min: 0
max: 80
- Emission -
lowMin: 0.0
lowMax: 0.0
highMin: 100.0
highMax: 150.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- Life -
lowMin: 0.0
lowMax: 0.0
highMin: 500.0
highMax: 900.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- Life Offset -
active: false
- X Offset -
active: false
- Y Offset -
active: false
- Spawn Shape -
shape: point
- Spawn Width -
lowMin: 0.0
lowMax: 0.0
highMin: 0.0
highMax: 0.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- Spawn Height -
lowMin: 0.0
lowMax: 0.0
highMin: 0.0
highMax: 0.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- X Scale -
lowMin: 0.0
lowMax: 0.0
highMin: 12.0
highMax: 28.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline: 0.0
- Y Scale -
active: false
- Velocity -
active: true
lowMin: 0.0
lowMax: 0.0
highMin: 60.0
highMax: 140.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline: 0.0
- Angle -
active: true
lowMin: 0.0
lowMax: 0.0
highMin: 0.0
highMax: 360.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline: 0.0
- Rotation -
active: false
- Wind -
active: false
- Gravity -
active: true
lowMin: 0.0
lowMax: 0.0
highMin: -50.0
highMax: -20.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- Tint -
colorCount: 3
colors0: 1.0
colors1: 0.4
colors2: 0.1
timelineCount: 1
timeline0: 0.0
- Transparency -
lowMin: 0.0
lowMax: 0.0
highMin: 1.0
highMax: 1.0
relative: false
scalingCount: 3
scaling0: 0.0
scaling1: 1.0
scaling2: 0.0
timelineCount: 3
timeline0: 0.0
timeline1: 0.2
timeline2: 1.0
- Options -
attached: false
continuos: false
aligned: false
additive: true
behind: false
premultipliedAlpha: false
- Image Paths -
particle.png

