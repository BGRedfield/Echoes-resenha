poeira
- Delay -
active: false
- Duration -
lowMin: 300.0
lowMax: 300.0
- Count -
min: 0
max: 50
- Emission -
lowMin: 0.0
lowMax: 0.0
highMin: 40.0
highMax: 60.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- Life -
lowMin: 0.0
lowMax: 0.0
highMin: 400.0
highMax: 700.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- Life Offset -
active: false
- X Offset -
active: false
- Y Offset -
active: false
- Spawn Shape -
shape: point
- Spawn Width -
lowMin: 0.0
lowMax: 0.0
highMin: 0.0
highMax: 0.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- Spawn Height -
lowMin: 0.0
lowMax: 0.0
highMin: 0.0
highMax: 0.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- X Scale -
lowMin: 0.0
lowMax: 0.0
highMin: 8.0
highMax: 16.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline: 0.0
- Y Scale -
active: false
- Velocity -
active: true
lowMin: 0.0
lowMax: 0.0
highMin: 20.0
highMax: 50.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline: 0.0
- Angle -
active: true
lowMin: 0.0
lowMax: 0.0
highMin: 70.0
highMax: 110.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline: 0.0
- Rotation -
active: false
- Wind -
active: false
- Gravity -
active: true
lowMin: 0.0
lowMax: 0.0
highMin: -30.0
highMax: -10.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- Tint -
colorCount: 3
colors0: 0.85
colors1: 0.45
colors2: 0.25
timelineCount: 1
timeline0: 0.0
- Transparency -
lowMin: 0.0
lowMax: 0.0
highMin: 1.0
highMax: 1.0
relative: false
scalingCount: 4
scaling0: 0.0
scaling1: 1.0
scaling2: 0.7
scaling3: 0.0
timelineCount: 4
timeline0: 0.0
timeline1: 0.2
timeline2: 0.7
timeline3: 1.0
- Options -
attached: false
continuos: false
aligned: false
additive: true
behind: false
premultipliedAlpha: false
- Image Paths -
particle.png

