rastro
- Delay -
active: false
- Duration -
lowMin: 200.0
lowMax: 200.0
- Count -
min: 0
max: 25
- Emission -
lowMin: 0.0
lowMax: 0.0
highMin: 20.0
highMax: 35.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- Life -
lowMin: 0.0
lowMax: 0.0
highMin: 300.0
highMax: 500.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- Life Offset -
active: false
- X Offset -
active: false
- Y Offset -
active: false
- Spawn Shape -
shape: point
- Spawn Width -
lowMin: 0.0
lowMax: 0.0
highMin: 0.0
highMax: 0.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- Spawn Height -
lowMin: 0.0
lowMax: 0.0
highMin: 0.0
highMax: 0.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline0: 0.0
- X Scale -
lowMin: 0.0
lowMax: 0.0
highMin: 5.0
highMax: 11.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline: 0.0
- Y Scale -
active: false
- Velocity -
active: true
lowMin: 0.0
lowMax: 0.0
highMin: 10.0
highMax: 30.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline: 0.0
- Angle -
active: true
lowMin: 0.0
lowMax: 0.0
highMin: 160.0
highMax: 200.0
relative: false
scalingCount: 1
scaling0: 1.0
timelineCount: 1
timeline: 0.0
- Rotation -
active: false
- Wind -
active: false
- Gravity -
active: false
- Tint -
colorCount: 3
colors0: 0.3
colors1: 0.7
colors2: 1.0
timelineCount: 1
timeline0: 0.0
- Transparency -
lowMin: 0.0
lowMax: 0.0
highMin: 1.0
highMax: 1.0
relative: false
scalingCount: 3
scaling0: 0.0
scaling1: 0.8
scaling2: 0.0
timelineCount: 3
timeline0: 0.0
timeline1: 0.3
timeline2: 1.0
- Options -
attached: false
continuos: false
aligned: false
additive: true
behind: false
premultipliedAlpha: false
- Image Paths -
particle.png

